﻿
namespace Task_no_1
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.next = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.Time = new System.Windows.Forms.Label();
            this.Date = new System.Windows.Forms.Label();
            this.SignInHeader = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LOGO = new System.Windows.Forms.PictureBox();
            this.role = new System.Windows.Forms.ComboBox();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.Emailtb = new System.Windows.Forms.TextBox();
            this.PhoneLabel = new System.Windows.Forms.Label();
            this.Phonetb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.passwordtb = new System.Windows.Forms.TextBox();
            this.usernametb = new System.Windows.Forms.TextBox();
            this.Timer = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LOGO)).BeginInit();
            this.SuspendLayout();
            // 
            // next
            // 
            this.next.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.next.BackColor = System.Drawing.Color.White;
            this.next.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.next.ForeColor = System.Drawing.Color.MidnightBlue;
            this.next.Location = new System.Drawing.Point(795, 472);
            this.next.Name = "next";
            this.next.Size = new System.Drawing.Size(121, 41);
            this.next.TabIndex = 8;
            this.next.Text = "Next";
            this.next.UseVisualStyleBackColor = false;
            this.next.Click += new System.EventHandler(this.button1_Click);
            this.next.MouseEnter += new System.EventHandler(this.next_MouseEnter);
            this.next.MouseLeave += new System.EventHandler(this.next_MouseLeave);
            // 
            // back
            // 
            this.back.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.back.BackColor = System.Drawing.Color.White;
            this.back.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back.ForeColor = System.Drawing.Color.MidnightBlue;
            this.back.Location = new System.Drawing.Point(122, 472);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(121, 41);
            this.back.TabIndex = 9;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.button2_Click);
            this.back.MouseEnter += new System.EventHandler(this.back_MouseEnter);
            this.back.MouseLeave += new System.EventHandler(this.back_MouseLeave);
            // 
            // Time
            // 
            this.Time.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Time.AutoSize = true;
            this.Time.BackColor = System.Drawing.Color.White;
            this.Time.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Time.ForeColor = System.Drawing.Color.MidnightBlue;
            this.Time.Location = new System.Drawing.Point(602, 9);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(60, 27);
            this.Time.TabIndex = 23;
            this.Time.Text = "Time";
            this.Time.Click += new System.EventHandler(this.Time_Click);
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.BackColor = System.Drawing.Color.White;
            this.Date.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Date.ForeColor = System.Drawing.Color.MidnightBlue;
            this.Date.Location = new System.Drawing.Point(12, 9);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(58, 27);
            this.Date.TabIndex = 22;
            this.Date.Text = "Date";
            // 
            // SignInHeader
            // 
            this.SignInHeader.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SignInHeader.AutoSize = true;
            this.SignInHeader.BackColor = System.Drawing.Color.White;
            this.SignInHeader.Font = new System.Drawing.Font("Times New Roman", 49.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SignInHeader.ForeColor = System.Drawing.Color.MidnightBlue;
            this.SignInHeader.Location = new System.Drawing.Point(212, 53);
            this.SignInHeader.Name = "SignInHeader";
            this.SignInHeader.Size = new System.Drawing.Size(536, 93);
            this.SignInHeader.TabIndex = 21;
            this.SignInHeader.Text = "Societies.UET";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.LOGO);
            this.panel1.Controls.Add(this.SignInHeader);
            this.panel1.Controls.Add(this.Time);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1026, 182);
            this.panel1.TabIndex = 29;
            // 
            // LOGO
            // 
            this.LOGO.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LOGO.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.LOGO.Image = global::Task_no_1.Properties.Resources.uet;
            this.LOGO.Location = new System.Drawing.Point(852, 9);
            this.LOGO.Margin = new System.Windows.Forms.Padding(13);
            this.LOGO.Name = "LOGO";
            this.LOGO.Padding = new System.Windows.Forms.Padding(10);
            this.LOGO.Size = new System.Drawing.Size(162, 159);
            this.LOGO.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.LOGO.TabIndex = 24;
            this.LOGO.TabStop = false;
            // 
            // role
            // 
            this.role.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.role.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.role.FormattingEnabled = true;
            this.role.Items.AddRange(new object[] {
            "Admin",
            "Student"});
            this.role.Location = new System.Drawing.Point(409, 417);
            this.role.Name = "role";
            this.role.Size = new System.Drawing.Size(278, 30);
            this.role.TabIndex = 5;
            // 
            // EmailLabel
            // 
            this.EmailLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.BackColor = System.Drawing.Color.MidnightBlue;
            this.EmailLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailLabel.ForeColor = System.Drawing.Color.White;
            this.EmailLabel.Location = new System.Drawing.Point(336, 379);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(63, 22);
            this.EmailLabel.TabIndex = 38;
            this.EmailLabel.Text = "Email:";
            // 
            // Emailtb
            // 
            this.Emailtb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Emailtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emailtb.Location = new System.Drawing.Point(409, 373);
            this.Emailtb.Name = "Emailtb";
            this.Emailtb.Size = new System.Drawing.Size(278, 30);
            this.Emailtb.TabIndex = 4;
            // 
            // PhoneLabel
            // 
            this.PhoneLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PhoneLabel.AutoSize = true;
            this.PhoneLabel.BackColor = System.Drawing.Color.MidnightBlue;
            this.PhoneLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneLabel.ForeColor = System.Drawing.Color.White;
            this.PhoneLabel.Location = new System.Drawing.Point(330, 333);
            this.PhoneLabel.Name = "PhoneLabel";
            this.PhoneLabel.Size = new System.Drawing.Size(69, 22);
            this.PhoneLabel.TabIndex = 36;
            this.PhoneLabel.Text = "Phone :";
            // 
            // Phonetb
            // 
            this.Phonetb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Phonetb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Phonetb.Location = new System.Drawing.Point(410, 327);
            this.Phonetb.Name = "Phonetb";
            this.Phonetb.Size = new System.Drawing.Size(278, 30);
            this.Phonetb.TabIndex = 3;
            this.Phonetb.TextChanged += new System.EventHandler(this.Phonetb_TextChanged);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.MidnightBlue;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(340, 420);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 22);
            this.label4.TabIndex = 34;
            this.label4.Text = "Role :";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.MidnightBlue;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(300, 287);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 22);
            this.label3.TabIndex = 33;
            this.label3.Text = "Password :";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.MidnightBlue;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(295, 242);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 22);
            this.label2.TabIndex = 32;
            this.label2.Text = "UserName :";
            // 
            // passwordtb
            // 
            this.passwordtb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.passwordtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordtb.Location = new System.Drawing.Point(410, 281);
            this.passwordtb.Name = "passwordtb";
            this.passwordtb.PasswordChar = '*';
            this.passwordtb.Size = new System.Drawing.Size(278, 30);
            this.passwordtb.TabIndex = 2;
            this.passwordtb.UseSystemPasswordChar = true;
            // 
            // usernametb
            // 
            this.usernametb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.usernametb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernametb.Location = new System.Drawing.Point(410, 236);
            this.usernametb.Name = "usernametb";
            this.usernametb.Size = new System.Drawing.Size(278, 30);
            this.usernametb.TabIndex = 1;
            this.usernametb.TextChanged += new System.EventHandler(this.usernametb_TextChanged);
            // 
            // Timer
            // 
            this.Timer.Enabled = true;
            this.Timer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // SignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(1026, 561);
            this.Controls.Add(this.role);
            this.Controls.Add(this.EmailLabel);
            this.Controls.Add(this.Emailtb);
            this.Controls.Add(this.PhoneLabel);
            this.Controls.Add(this.Phonetb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.passwordtb);
            this.Controls.Add(this.usernametb);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.back);
            this.Controls.Add(this.next);
            this.Controls.Add(this.panel1);
            this.Name = "SignUp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "s";
            this.Load += new System.EventHandler(this.SignUp_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LOGO)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Label Time;
        private System.Windows.Forms.Label Date;
        private System.Windows.Forms.Label SignInHeader;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox LOGO;
        private System.Windows.Forms.ComboBox role;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.TextBox Emailtb;
        private System.Windows.Forms.Label PhoneLabel;
        private System.Windows.Forms.TextBox Phonetb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox passwordtb;
        private System.Windows.Forms.TextBox usernametb;
        private System.Windows.Forms.Timer Timer;
    }
}