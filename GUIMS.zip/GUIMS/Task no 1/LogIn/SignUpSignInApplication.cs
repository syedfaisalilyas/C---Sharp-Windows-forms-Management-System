﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using Task_no_1.BL;
using Task_no_1.DL;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task_no_1
{
    public partial class SignUpSignInApplication : Form
    {
        public SignUpSignInApplication()
        {
            InitializeComponent();
          
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(SignIN.Checked)
            {
                Form moreform = new SignIn();
                moreform.Show();
                SignIN.Checked = false;
            }
            else if(SignUP.Checked)
            {
                Form moreForm = new SignUp();
                moreForm.Show();
                SignUP.Checked = false;
            }
        }

        private void SignUpSignInApplication_Load(object sender, EventArgs e)
        {

        }

        private void Time_Click(object sender, EventArgs e)
        {

        }

        private void SignInHeader_Click(object sender, EventArgs e)
        {

        }

        private void Date_Click(object sender, EventArgs e)
        {

        }

        private void SignUpSignInApplication_Load_1(object sender, EventArgs e)
        {
            SocietyDL.readsocietydata();
            SocietyMemberDL.readmemberdata();
            SocietyDL.loaddonation();
            SocietyDL.loadfeedback();
            SocietyDL.loadreq();
            SocietyDL.loadevent();
            SocietyDL.loadmission();
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Data.txt";
            if (MUserDL.readdata(path))
            {
                MessageBox.Show("Data Loaded from File");
            }
            else
            {
                MessageBox.Show("Data Not Loaded from File");
            }
        }

        private void Time_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void SignIN_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void SignInHeader_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
   
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.DarkBlue;
            button1.ForeColor = Color.White;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.White;
            button1.ForeColor = Color.MidnightBlue;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Date.Text = "Date: " + DateTime.Now.ToString("MMMM dd, yyyy");
            Time.Text = "Time: " + DateTime.Now.ToString("hh:mm:ss tt");
        }
    }
}
