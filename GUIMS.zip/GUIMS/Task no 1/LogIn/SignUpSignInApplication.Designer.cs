﻿
namespace Task_no_1
{
    partial class SignUpSignInApplication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SignIN = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Date = new System.Windows.Forms.Label();
            this.SignInHeader = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Time = new System.Windows.Forms.Label();
            this.SignUP = new System.Windows.Forms.CheckBox();
            this.Timer = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // SignIN
            // 
            this.SignIN.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SignIN.AutoSize = true;
            this.SignIN.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SignIN.ForeColor = System.Drawing.Color.White;
            this.SignIN.Location = new System.Drawing.Point(609, 321);
            this.SignIN.Name = "SignIN";
            this.SignIN.Size = new System.Drawing.Size(140, 47);
            this.SignIN.TabIndex = 2;
            this.SignIN.Text = "SignIn";
            this.SignIN.UseVisualStyleBackColor = true;
            this.SignIN.CheckedChanged += new System.EventHandler(this.SignIN_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button1.Location = new System.Drawing.Point(802, 465);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(169, 50);
            this.button1.TabIndex = 3;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.MouseEnter += new System.EventHandler(this.button1_MouseEnter);
            this.button1.MouseLeave += new System.EventHandler(this.button1_MouseLeave);
            this.button1.MouseHover += new System.EventHandler(this.button1_MouseHover);
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Date.ForeColor = System.Drawing.Color.MidnightBlue;
            this.Date.Location = new System.Drawing.Point(10, 6);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(58, 27);
            this.Date.TabIndex = 22;
            this.Date.Text = "Date";
            // 
            // SignInHeader
            // 
            this.SignInHeader.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SignInHeader.AutoSize = true;
            this.SignInHeader.BackColor = System.Drawing.Color.White;
            this.SignInHeader.Font = new System.Drawing.Font("Times New Roman", 49.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SignInHeader.ForeColor = System.Drawing.Color.MidnightBlue;
            this.SignInHeader.Location = new System.Drawing.Point(206, 55);
            this.SignInHeader.Name = "SignInHeader";
            this.SignInHeader.Size = new System.Drawing.Size(541, 95);
            this.SignInHeader.TabIndex = 21;
            this.SignInHeader.Text = "Societies.UET";
            this.SignInHeader.Click += new System.EventHandler(this.SignInHeader_Click_1);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.SignInHeader);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.Time);
            this.panel1.Controls.Add(this.Date);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1030, 182);
            this.panel1.TabIndex = 24;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox1.Image = global::Task_no_1.Properties.Resources.uet;
            this.pictureBox1.Location = new System.Drawing.Point(854, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(176, 182);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Time
            // 
            this.Time.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Time.AutoSize = true;
            this.Time.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Time.ForeColor = System.Drawing.Color.MidnightBlue;
            this.Time.Location = new System.Drawing.Point(628, 6);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(60, 27);
            this.Time.TabIndex = 23;
            this.Time.Text = "Time";
            this.Time.Click += new System.EventHandler(this.Time_Click_1);
            // 
            // SignUP
            // 
            this.SignUP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SignUP.AutoSize = true;
            this.SignUP.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SignUP.ForeColor = System.Drawing.Color.White;
            this.SignUP.Location = new System.Drawing.Point(239, 321);
            this.SignUP.Name = "SignUP";
            this.SignUP.Size = new System.Drawing.Size(156, 47);
            this.SignUP.TabIndex = 1;
            this.SignUP.Text = "SignUp";
            this.SignUP.UseVisualStyleBackColor = true;
            // 
            // Timer
            // 
            this.Timer.Enabled = true;
            this.Timer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // SignUpSignInApplication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(1030, 561);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SignIN);
            this.Controls.Add(this.SignUP);
            this.Name = "SignUpSignInApplication";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "starter";
            this.Load += new System.EventHandler(this.SignUpSignInApplication_Load_1);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.CheckBox SignIN;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Date;
        private System.Windows.Forms.Label SignInHeader;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Time;
        private System.Windows.Forms.CheckBox SignUP;
        private System.Windows.Forms.Timer Timer;
    }
}