﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.BL;
using Task_no_1.DL;

namespace Task_no_1
{
    public partial class SignIn : Form
    {
        public SignIn()
        {
            InitializeComponent();
            

        }

        private void ClearDatafromForm()
        {
            usernametext.Text = "";
            passwordtext.Text = "";
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SignIn_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = usernametext.Text;
            string password = passwordtext.Text;
            if (string.IsNullOrWhiteSpace(usernametext.Text))
            {
                MessageBox.Show("Username cannot be left blank.");
                usernametext.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(passwordtext.Text))
            {
                MessageBox.Show("Password cannot be left blank.");
                passwordtext.Focus();
                return;
            }
            MUser user = new MUser(username,password);
            MUser validuser = MUserDL.SignIn(user);
            if (validuser != null)
            {
                if (validuser.isAdmin())
                {
                    Adminform adminform = new Adminform();
                    adminform.Show();
                }
                else if(validuser.isStudent())
                {
                    Studentform studentform = new Studentform();
                    studentform.Show();
                }
            }
            else
            {
                MessageBox.Show("User is Invalid");
                usernametext.Focus();
            }
            ClearDatafromForm();
           
            

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void SignInHeader_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                passwordtext.PasswordChar = '\0';
            }
            else
            {
                passwordtext.PasswordChar = '*';

            }
        }

        private void passwordtext_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.DarkBlue;
            button1.ForeColor = Color.White;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.White;
            button1.ForeColor = Color.MidnightBlue;
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button2.BackColor = Color.DarkBlue;
            button2.ForeColor = Color.White;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.White;
            button2.ForeColor = Color.MidnightBlue;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Date.Text = "Date: " + DateTime.Now.ToString("MMMM dd, yyyy");
            Time.Text = "Time: " + DateTime.Now.ToString("hh:mm:ss tt");
        }
    }
}
