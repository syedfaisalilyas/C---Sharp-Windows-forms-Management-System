﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.BL;
using Task_no_1.DL;

namespace Task_no_1
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
 
        }

        private void cleardatafromform()
        {
            usernametb.Text = "";
            passwordtb.Text = "";
            Phonetb.Text = "";
            Emailtb.Text = ""; 
            role.Text = "";
        }
     

        private void button1_Click(object sender, EventArgs e)
        {
            Regex emailRegex = new Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
            MUser User = new MUser();
            input_username:
            string username = usernametb.Text;
            string password = passwordtb.Text;
            input_phone:
            string phone = Phonetb.Text;
            input_email:
            string email = Emailtb.Text;
            string Role = role.SelectedItem?.ToString();
            
            if (string.IsNullOrWhiteSpace(usernametb.Text))
            {
                MessageBox.Show("Username cannot be left blank.");
                usernametb.Focus();
                return;
            }
            else if (string.IsNullOrWhiteSpace(passwordtb.Text))
            {
                MessageBox.Show("Password cannot be left blank.");
                passwordtb.Focus();
                return;
            }
            else if (string.IsNullOrWhiteSpace(Phonetb.Text))
            {
                MessageBox.Show("Phone number cannot be left blank.");
                Phonetb.Focus();
                return;
            }
            else if (string.IsNullOrWhiteSpace(Emailtb.Text))
            {
                MessageBox.Show("Email cannot be left blank.");
                Emailtb.Focus();
                return;
            }
            else if (string.IsNullOrWhiteSpace(Role))
            {
                MessageBox.Show("Role cannot be left blank.");
                role.Focus();
                return;
            }
          
            if (User.is_username_exist(usernametb.Text))
            {
                MessageBox.Show("Username already exists");
                usernametb.Clear();
                usernametb.Focus();
                goto input_username;
            }
            if(User.is_phone_exist(Phonetb.Text))
            {
                MessageBox.Show("Phone Number already exists");
                Phonetb.Clear();
                Phonetb.Focus();
                goto input_phone;
            }
            if(User.is_email_exist(Emailtb.Text))
            {
                MessageBox.Show("Email already exists");
                Emailtb.Clear();
                Emailtb.Focus();
                goto input_email;
            }

            if (!emailRegex.IsMatch(Emailtb.Text))
            {
                MessageBox.Show("Invalid Email! Please enter a valid Email.");
                Emailtb.Clear();
                Emailtb.Focus();
                goto input_email;
            }
         /*   if (!(role.Equals("Admin", StringComparison.OrdinalIgnoreCase) || role.Equals("Student", StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show("Invalid Role! Please enter the role as Admin or Student.");
                roletb.Clear();
                roletb.Focus();
                goto input_role;
            }*/
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Data.txt";
            if( usernametb.Text != string.Empty && passwordtb.Text != string.Empty && Phonetb.Text!= string.Empty && Emailtb.Text!= string.Empty && role.Text!= string.Empty)
            {
            MUser user = new MUser(username, password,phone,email, Role);
            MUserDL.AddtoUserlist(user);
            MUserDL.storedata(user, path);
            MessageBox.Show("Data Loaaded SuccessFully");
            cleardatafromform();
            this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void username_TextChanged(object sender, EventArgs e)
        {

        }

        private void password_TextChanged(object sender, EventArgs e)
        {

        }

        private void PhonetextBox_TextChanged(object sender, EventArgs e)
        {
            
        }
       /* private void textBox3_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string role = roletb.Text;
            if (!u.isString(role))
            {
                MessageBox.Show("Invalid Role! Please enter role as Admin or Student.");
                roletb.Clear();
                roletb.Focus();
            }

        }*/
        private void SignUp_Load(object sender, EventArgs e)
        {
         
        }

        private void Time_Click(object sender, EventArgs e)
        {

        }

        private void Emailtb_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void usernametb_TextChanged(object sender, EventArgs e)
        {

        }

        private void next_MouseEnter(object sender, EventArgs e)
        {
            next.BackColor = Color.DarkBlue;
            next.ForeColor = Color.White;
        }

        private void next_MouseLeave(object sender, EventArgs e)
        {
            next.BackColor = Color.White;
            next.ForeColor = Color.MidnightBlue;
        }

        private void back_MouseEnter(object sender, EventArgs e)
        {
            back.BackColor = Color.DarkBlue;
            back.ForeColor = Color.White;
        }

        private void back_MouseLeave(object sender, EventArgs e)
        {
            back.BackColor = Color.White;
            back.ForeColor = Color.MidnightBlue;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Date.Text = "Date: " + DateTime.Now.ToString("MMMM dd, yyyy");
            Time.Text = "Time: " + DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void Phonetb_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string phone = Phonetb.Text;
            if (!u.isInteger(phone))
            {
                MessageBox.Show("Invalid input! Please enter a valid Phone Number.");
                Phonetb.Clear();
                Phonetb.Focus();
            }
        }
    }
}
