﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task_no_1.DL;

namespace Task_no_1.BL
{
   public class MUser : Person
    {
        private string Name;
        private string Password;
        private string Phone;
        private string Email;
        private string Role;

        public string Name1 { get => Name; set => Name = value; }
        public string Password1 { get => Password; set => Password = value; }
        public string Phone1 { get => Phone; set => Phone = value; }
        public string Email1 { get => Email; set => Email = value; }
        public string Role1 { get => Role; set => Role = value; }

        public MUser() { }
        public MUser(string Name,string Password,string Phone,string Email,string Role)
        {
            this.Name = Name;
            this.Password = Password;
            this.Phone = Phone;
            this.Email = Email;
            this.Role = Role;
        }
        public MUser(string Name, string Password)
        {
            this.Name = Name;
            this.Password = Password;
        }

        public bool is_username_exist(string usern)
        {
            foreach (MUser i in MUserDL.Loginusers)
            {
                if (usern == i.Name)
                {
                    return true;
                }
            }
            return false;
        }

        public bool is_phone_exist(string phonen)
        {
            foreach (MUser i in MUserDL.Loginusers)
            {
                if (phonen == i.Phone)
                {
                    return true;
                }
            }
            return false;
        }

        public bool is_email_exist(string em)
        {
            foreach (MUser i in MUserDL.Loginusers)
            {
                if (em == i.Email)
                {
                    return true;
                }
            }
            return false;
        }
        public bool isAdmin()
        {
            if(Role == "Admin")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool isStudent()
        {
            if(Role == "Student")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool isString(string str)
        {

            for (int i = 0; i < str.Length; i++)
            {
                if ((!char.IsLetter(str[i])) && str[i] != ' ')
                {
                    return false;
                }
            }
            return true;
        }
        public bool isInteger(string str)
        {

            for (int i = 0; i < str.Length; i++)
            {
                if ((!char.IsDigit(str[i])) && str[i] != ' ')
                {
                    return false;
                }
            }
            return true;
        }
    }
}
