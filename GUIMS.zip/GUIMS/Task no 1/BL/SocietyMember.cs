﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_no_1.BL
{
    class SocietyMember:Person
    {
        private string society_member_username;
        private string society_member_email;
        private string society_member_contact;

        public string Society_member_username { get => society_member_username; set => society_member_username = value; }
        public string Society_member_email { get => society_member_email; set => society_member_email = value; }
        public string Society_member_contact { get => society_member_contact; set => society_member_contact = value; }

        public SocietyMember()
        {
        }

        public SocietyMember(string society_member_username, string society_member_email, string society_member_contact)
        {
            this.society_member_username = society_member_username;
            this.society_member_email = society_member_email;
            this.society_member_contact = society_member_contact;
        }
    }
}
