﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_no_1.BL
{
    class Society
    {
        private string society_description;
        private string society_name;
        private string society_president;

        public string Society_description { get => society_description; set => society_description = value; }
        public string Society_name { get => society_name; set => society_name = value; }
        public string Society_president { get => society_president; set => society_president = value; }

        public Society()
        {

        }

        public Society(string society_name, string society_description, string society_president)
        {
            this.society_name = society_name;
            this.society_description = society_description;
            this.society_president = society_president;
        }

    }
}
