﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.DL;

namespace Task_no_1.Student
{
    public partial class Request : Form
    {
        public Request()
        {
            InitializeComponent();
        }

        private void Request_Load(object sender, EventArgs e)
        {
         
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void cleardata()
        {
            requesttb.Text = "";
        }
        private void next_Click(object sender, EventArgs e)
        {
            SocietyDL a = new SocietyDL();
            string request = requesttb.Text;
            if (string.IsNullOrWhiteSpace(requesttb.Text))
            {
                MessageBox.Show("Request cannot be left blank.");
                requesttb.Focus();
                return;
            }
            SocietyDL.addtorequestlist(request);
            a.storereq(request);
            MessageBox.Show("Request sent Successfully!");
            cleardata();
            this.Close();
        }
    }
}
