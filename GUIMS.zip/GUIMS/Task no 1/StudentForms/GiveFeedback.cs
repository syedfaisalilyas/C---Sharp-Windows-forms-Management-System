﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.BL;
using Task_no_1.DL;

namespace Task_no_1.Student
{
    public partial class GiveFeedback : Form
    {
        public GiveFeedback()
        {
            InitializeComponent();
        }

        private void cleardata()
        {
            feedbacktb.Text = "";
        }
        private void GiveFeedback_Load(object sender, EventArgs e)
        {
           
        }

        private void next_Click(object sender, EventArgs e)
        {
            SocietyDL a = new SocietyDL();
            string feedback = feedbacktb.Text;
            if (string.IsNullOrWhiteSpace(feedbacktb.Text))
            {
                MessageBox.Show("Feedback cannot be left blank.");
                feedbacktb.Focus();
                return;
            }
            SocietyDL.addtofeedbacklist(feedback);
            a.storefeedback(feedback);
            MessageBox.Show("Feedback sent Successfully!");
            cleardata();
            this.Close();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void feedbacktb_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string feedback = feedbacktb.Text;
            if (!u.isString(feedback))
            {
                MessageBox.Show("Invalid Role! Please enter a Valid Name.");
                feedbacktb.Clear();
                feedbacktb.Focus();
            }
        }
    }
}
