﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.BL;
using Task_no_1.DL;

namespace Task_no_1.Student
{
    public partial class Donation : Form
    {
        public Donation()
        {
            InitializeComponent();
        }

        private void cleardata()
        {
            Nametb.Text = "";
            aMounttb.Text = "";
        }
        private void Donation_Load(object sender, EventArgs e)
        {
        }

        private void usernametb_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string name = Nametb.Text;
            if (!u.isString(name))
            {
                MessageBox.Show("Invalid Role! Please enter a Valid Name.");
                Nametb.Clear();
                Nametb.Focus();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string amount = aMounttb.Text;
            if (!u.isInteger(amount))
            {
                MessageBox.Show("Invalid input! Please enter a valid Amount.");
                aMounttb.Clear();
                aMounttb.Focus();
            }
        }

        private void next_Click(object sender, EventArgs e)
        {
            SocietyDL a = new SocietyDL();
            string name = Nametb.Text;
            string ammount = aMounttb.Text;
            if (string.IsNullOrWhiteSpace(Nametb.Text))
            {
                MessageBox.Show("Name cannot be left blank.");
                Nametb.Focus();
                return;
            }
            else if (string.IsNullOrWhiteSpace(aMounttb.Text))
            {
                MessageBox.Show("Amount cannot be left blank.");
                aMounttb.Focus();
                return;
            }
            SocietyDL.addtodonationNameslist(name);
            SocietyDL.addtodonationslist(ammount);
            a.storedonation(name, ammount);
            MessageBox.Show("Donated Successfully!");
            cleardata();
            this.Close();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
