﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.Admin;
using Task_no_1.Student;

namespace Task_no_1
{
    public partial class Studentform : Form
    {
        private bool slidebarexpand;
        private bool memberoptions;
        private Form currentchildform;

        public Studentform()
        {
            InitializeComponent();
            MainMenu a = new MainMenu();
            a.ShowDialog();


        }

        private void openform(Form childform)
        {
            if (currentchildform != null)
            {
                currentchildform.Close();
            }
            currentchildform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            mainpanel.Controls.Add(childform);
            mainpanel.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }
        private void Student_Load(object sender, EventArgs e)
        {
                     
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void SignInHeader_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddMember a = new AddMember();
            a.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            GiveFeedback a = new GiveFeedback();
            a.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Request r = new Request();
            r.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UpdateMember a = new UpdateMember();
            a.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            RemoveMember r = new RemoveMember();
            r.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
           DisplayEvents a = new DisplayEvents();
            a.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DisplayFeedbacks a = new DisplayFeedbacks();
            a.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            DisplayMembers a = new DisplayMembers();
            a.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Donation d = new Donation();
            d.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            DisplaySocieties a = new DisplaySocieties();
            a.Show();
              
        }

        private void slidebar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {
            membertimer.Start();

        }

        private void slider_Tick(object sender, EventArgs e)
        {
            if (slidebarexpand)
            {
                slidebar.Width -= 10;
                if (slidebar.Width <= slidebar.MinimumSize.Width)
                {
                    slidebarexpand = false;
                    slider.Stop();
                }
            }
            else
            {
                slidebar.Width += 10;
                if (slidebar.Width >= slidebar.MaximumSize.Width)
                {
                    slidebarexpand = true;
                    slider.Stop();
                }

            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            slider.Start();
        }

        private void membertimer_Tick(object sender, EventArgs e)
        {
            if (memberoptions)
            {
                Memberpanel.Height -= 10;
                Memberpanel.Width -= 10;
                if (Memberpanel.Height <= Memberpanel.MinimumSize.Height && Memberpanel.Width <= Memberpanel.MinimumSize.Width)
                {
                    memberoptions = false;
                    membertimer.Stop();
                }
            }
            else
            {
                Memberpanel.Height += 10;
                Memberpanel.Width += 10;
                if (Memberpanel.Height >= Memberpanel.MaximumSize.Height && Memberpanel.Width >= Memberpanel.MaximumSize.Width)
                {
                    memberoptions = true;
                    membertimer.Stop();
                }

            }
        }

        private void mainpanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button27_Click(object sender, EventArgs e)
        {
            openform(new AddMember());
        }

        private void button25_Click(object sender, EventArgs e)
        {
            openform(new UpdateMember());
        }

        private void button26_Click(object sender, EventArgs e)
        {
            openform(new Displaymemberforstudent());
        }

        private void button13_Click(object sender, EventArgs e)
        {
            openform(new DisplaySocietiesForStudent());
        }

        private void button17_Click(object sender, EventArgs e)
        {
            openform(new DisplayEvents());
        }

        private void button20_Click(object sender, EventArgs e)
        {
            openform(new DisplayMission());
        }

        private void button19_Click(object sender, EventArgs e)
        {
            openform(new GiveFeedback());
        }

        private void button18_Click(object sender, EventArgs e)
        {
            openform(new Donation());
        }

        private void button32_Click(object sender, EventArgs e)
        {
            openform(new Request());
        }

        private void button14_Click(object sender, EventArgs e)
        {
            openform(new DisplayFeedbacksforStudent());
        }

        private void button21_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Click(object sender, EventArgs e)
        {
            if (currentchildform != null)
                currentchildform.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            if (currentchildform != null)
                currentchildform.Close();
        }

        private void datendtime_Tick(object sender, EventArgs e)
        {
            Date.Text = "Date: " + DateTime.Now.ToString("MMMM dd, yyyy");
            Time.Text = "Time: " + DateTime.Now.ToString("hh:mm:ss tt");
        }
    }
}
