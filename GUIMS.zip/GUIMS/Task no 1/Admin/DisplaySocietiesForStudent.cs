﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class DisplaySocietiesForStudent : Form
    {
        public DisplaySocietiesForStudent()
        {
            InitializeComponent();
            databind();
        }
        private void databind()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = PersonDL.societylist.Select(c => new { c.Society_name, c.Society_president, c.Society_description }).ToList();
            CustomizeDataGridView();
            dataGridView1.Refresh();
        }

        private void CustomizeDataGridView()
        {
            // Set the column widths
            dataGridView1.Columns["Society_name"].Width = 200;
            dataGridView1.Columns["Society_president"].Width = 250;
            dataGridView1.Columns["Society_description"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            // Set the column header font size and style
            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            headerStyle.Font = new Font("Arial", 12, FontStyle.Bold);
            dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;

            // Set the row header font size and style
            dataGridView1.RowHeadersDefaultCellStyle.Font = new Font("Arial", 10);

            // Set the row height
            dataGridView1.RowTemplate.Height = 40;

            // Center align data in columns
            dataGridView1.Columns["Society_name"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Society_president"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Society_description"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Increase the font size of the data in all columns by a little
            DataGridViewCellStyle dataCellStyle = new DataGridViewCellStyle();
            dataCellStyle.Font = new Font("Arial", 11);
            dataGridView1.DefaultCellStyle = dataCellStyle;

            dataGridView1.RowsDefaultCellStyle.BackColor = Color.White;
            dataGridView1.RowsDefaultCellStyle.ForeColor = Color.Black;
            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.LightBlue;

        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
