﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.BL;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class AddSociety : Form
    {
        public AddSociety()
        {
            InitializeComponent();
       
        }
        private void cleardatafromform()
        {
            nametext.Text = "";
            presidenttext.Text = "";
            descriptiontext.Text = "";
        }
        private void Time_Click(object sender, EventArgs e)
        {

        }

        private void AddSociety_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           

            
        }

        private void AddSociety_Load_1(object sender, EventArgs e)
        {
           
        }

        private void usernametb_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string name = nametext.Text;
            if (!u.isString(name))
            {
                MessageBox.Show("Invalid Name! Please enter a valid Name.");
                nametext.Clear();
                nametext.Focus();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string president = presidenttext.Text;
            if (!u.isString(president))
            {
                MessageBox.Show("Invalid Name! Please enter a valid Name.");
                presidenttext.Clear();
                presidenttext.Focus();
            }
        }

        private void timee_Click(object sender, EventArgs e)
        {

        }

        private void next_Click(object sender, EventArgs e)
        {
            string name = nametext.Text;
            string president = presidenttext.Text;
            string description = descriptiontext.Text;
            if (string.IsNullOrWhiteSpace(nametext.Text))
            {
                MessageBox.Show("Name cannot be left blank.");
                nametext.Focus();
                return;
            }
            else if (string.IsNullOrWhiteSpace(presidenttext.Text))
            {
                MessageBox.Show("President cannot be left blank.");
                presidenttext.Focus();
                return;
            }
            else if (string.IsNullOrWhiteSpace(descriptiontext.Text))
            {
                MessageBox.Show("Description cannot be left blank.");
                descriptiontext.Focus();
                return;
            }
            SocietyDL soc = new SocietyDL();
            if (nametext.Text != string.Empty && presidenttext.Text != string.Empty && descriptiontext.Text != string.Empty)
            {
                Society s = new Society(name, president, description);
                SocietyDL.addtosociety(s);
                soc.storesocietydata(s);
                MessageBox.Show("Data Loaaded SuccessFully");
                cleardatafromform();
                this.Close();
            }
        }
    }
}