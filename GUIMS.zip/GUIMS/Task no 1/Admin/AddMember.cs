﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.BL;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class AddMember : Form
    {
        public AddMember()
        {
            InitializeComponent();

        }
        private void cleardatafromform()
        {
            usernametb.Text = "";
            Emailtb.Text = "";
            phonetb.Text = "";
        }
        private void AddMember_Load(object sender, EventArgs e)
        {
           
        }

        private void SignInHeader_Click(object sender, EventArgs e)
        {

        }

        private void next_Click(object sender, EventArgs e)
        {
            Regex emailRegex = new Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
            string name = usernametb.Text;
            input_email:
            string email = Emailtb.Text;
            string phone = phonetb.Text;
            if (string.IsNullOrWhiteSpace(usernametb.Text))
            {
                MessageBox.Show("Username cannot be left blank.");
                usernametb.Focus();
                return;
            }
            else if (string.IsNullOrWhiteSpace(Emailtb.Text))
            {
                MessageBox.Show("Email cannot be left blank.");
                Emailtb.Focus();
                return;
            }
            else if (string.IsNullOrWhiteSpace(phonetb.Text))
            {
                MessageBox.Show("Phone number cannot be left blank.");
                phonetb.Focus();
                return;
            }
            if (!emailRegex.IsMatch(Emailtb.Text))
            {
                MessageBox.Show("Invalid Email! Please enter a valid Email.");
                Emailtb.Clear();
                Emailtb.Focus();
                goto input_email;
            }
            SocietyMemberDL s = new SocietyMemberDL();
            if (usernametb.Text != string.Empty && Emailtb.Text != string.Empty && phonetb.Text != string.Empty)
            {
                SocietyMember sm = new SocietyMember(name,email,phone);
                SocietyMemberDL.addtosocietyUsers(sm);
                s.storememberdata(sm);
                MessageBox.Show("Data Loaaded SuccessFully");
                cleardatafromform();
                this.Close();
            }
        }

        private void phonetb_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string phone = phonetb.Text;
            if (!u.isInteger(phone))
            {
                MessageBox.Show("Invalid input! Please enter a valid Phone Number.");
                phonetb.Clear();
                phonetb.Focus();
            }
        }

        private void Emailtb_TextChanged(object sender, EventArgs e)
        {

        }


        private void usernametb_TextChanged_1(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string name = usernametb.Text;
            if (!u.isString(name))
            {
                MessageBox.Show("Invalid Role! Please enter a valid Name.");
                usernametb.Clear();
                usernametb.Focus();
            }
        }
    }
}
   
   