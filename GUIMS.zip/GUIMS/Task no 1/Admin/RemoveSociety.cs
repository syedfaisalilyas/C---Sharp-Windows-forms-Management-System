﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.BL;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class RemoveSociety : Form
    {
        public RemoveSociety()
        {
            InitializeComponent();
            InitializeCustomButtons();
        }

        private void cleardata()
        {
            usernametb.Text = "";
        }
        private void usernametb_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string name = usernametb.Text;
            if (!u.isString(name))
            {
                MessageBox.Show("Invalid Role! Please enter a valid Name.");
                usernametb.Clear();
                usernametb.Focus();
            }
        }
        private void InitializeCustomButtons()
        {
            // Create the Next button with rounded edges
            Button nextButton = new Button();
            nextButton.Text = "Next";
            nextButton.Location = new Point(100, 100);
            nextButton.Size = new Size(150, 40);
            nextButton.FlatStyle = FlatStyle.Flat;
            nextButton.BackColor = Color.MediumSlateBlue;
            nextButton.ForeColor = Color.White;
            nextButton.FlatAppearance.BorderSize = 0;
            nextButton.FlatAppearance.MouseDownBackColor = Color.DarkSlateBlue;
            nextButton.FlatAppearance.MouseOverBackColor = Color.SlateBlue;
            nextButton.Click += next_Click;
            this.Controls.Add(nextButton);

            // Create the Back button with rounded edges
            Button backButton = new Button();
            backButton.Text = "Back";
            backButton.Location = new Point(100, 150);
            backButton.Size = new Size(150, 40);
            backButton.FlatStyle = FlatStyle.Flat;
            backButton.BackColor = Color.MediumSlateBlue;
            backButton.ForeColor = Color.White;
            backButton.FlatAppearance.BorderSize = 0;
            backButton.FlatAppearance.MouseDownBackColor = Color.DarkSlateBlue;
            backButton.FlatAppearance.MouseOverBackColor = Color.SlateBlue;
            backButton.Click += back_Click;
            this.Controls.Add(backButton);
        }

        private void RemoveSociety_Load(object sender, EventArgs e)
        {
            Date.Text = "Date: " + DateTime.Now.ToString("MMMM dd, yyyy");
            Time.Text = "Time: " + DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void next_Click(object sender, EventArgs e)
        {
            bool flag = false;
            string name = usernametb.Text;
            foreach (Society i in PersonDL.societylist)
            {
                if (i.Society_name == name)
                {
                    PersonDL.societylist.Remove(i);
                    SocietyDL.writedatinfile();
                    MessageBox.Show("Society name changed successfully!");
                    this.Close();
                    flag = true;
                    break;
                }
            }
            if (flag == true)
            {
                MessageBox.Show("Society name not found!");
                cleardata();
            }
        }

        private void back_Click(object sender, EventArgs e)
        {

        }
    }
}
