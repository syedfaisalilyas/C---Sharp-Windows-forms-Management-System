﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.BL;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class EditMission : Form
    {
        public EditMission()
        {
            InitializeComponent();
        }
        private void cleardata()
        {
            missiontb.Text = "";
        }
        private void EditMission_Load(object sender, EventArgs e)
        {
          
        }

        private void next_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(missiontb.Text))
            {
                MessageBox.Show("Mission cannot be left blank.");
                missiontb.Focus();
                return;
            }
            SocietyDL.addtomissionlist(missiontb.Text);
            SocietyDL.storemission(missiontb.Text);
            cleardata();
            this.Close();
        }
    }
}
