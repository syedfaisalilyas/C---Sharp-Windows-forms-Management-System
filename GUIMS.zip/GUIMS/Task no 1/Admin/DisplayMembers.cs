﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class DisplayMembers : Form
    {
        public DisplayMembers()
        {
            InitializeComponent();
            databind();
        }

        private void databind()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = PersonDL.societyuserlist.Select(c => new { c.Society_member_username, c.Society_member_email, c.Society_member_contact }).ToList();
            CustomizeDataGridView();
            dataGridView1.Refresh();
        }

        private void CustomizeDataGridView()
        {
            // Set the AutoSizeMode for each column to fit the content
            dataGridView1.Columns["Society_member_username"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns["Society_member_email"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns["Society_member_contact"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            // Set the column headers' font size, style, and alignment
            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            headerStyle.Font = new Font("Arial", 12, FontStyle.Bold);
            headerStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;


            // Set the row height
            dataGridView1.RowTemplate.Height = 40;

            // Increase the font size of the data in all columns by a little
            DataGridViewCellStyle dataCellStyle = new DataGridViewCellStyle();
            dataCellStyle.Font = new Font("Arial", 11);
            dataGridView1.DefaultCellStyle = dataCellStyle;

            // Center align data in columns
            dataGridView1.Columns["Society_member_username"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Society_member_email"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Society_member_contact"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Apply alternating row colors for better readability
            dataGridView1.RowsDefaultCellStyle.BackColor = Color.White;
            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;

            // Add a search bar to filter rows based on user input
            searchTextBox.TextChanged += SearchTextBox_TextChanged;
            searchTextBox.BringToFront();
            searchTextBox.BackColor = Color.White;
            searchTextBox.ForeColor = Color.Black;
            searchTextBox.BorderStyle = BorderStyle.FixedSingle;
            searchTextBox.Text = "Search...";
            searchTextBox.GotFocus += SearchTextBox_GotFocus;
            searchTextBox.LostFocus += SearchTextBox_LostFocus;

        }
        // Handle search box got focus
        private void SearchTextBox_GotFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (textBox.Text == "Search...")
            {
                textBox.Text = string.Empty;
                textBox.ForeColor = Color.Black;
            }
        }

        // Handle search box lost focus
        private void SearchTextBox_LostFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Search...";
                textBox.ForeColor = Color.DarkGray;
            }
        }

        // Search box text changed event
        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            TextBox searchTextBox = (TextBox)sender;
            string searchKeyword = searchTextBox.Text.ToLower();
            bool cellFound = false;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchKeyword))
                    {
                        cell.Selected = true; // Select the cell if it contains the search keyword
                        dataGridView1.CurrentCell = cell; // Set this cell as the current cell
                        cellFound = true;
                        break; // Exit the inner loop after finding the first matching cell
                    }
                }

                if (cellFound)
                    break; // Exit the outer loop if the cell is found
            }
        }
        private void delete_Click(object sender, EventArgs e)
        {
         
                PersonDL.societyuserlist.RemoveAt(dataGridView1.CurrentRow.Index);
                SocietyMemberDL.writedatinfile();
                databind();
        }

      
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void searchTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void DisplayMembers_Load(object sender, EventArgs e)
        {

        }
    }
}
