﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class DisplaySocieties : Form
    {
        public DisplaySocieties()
        {
            InitializeComponent();
            databind();
        }

        private void databind()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = PersonDL.societylist.Select(c => new { c.Society_name, c.Society_president, c.Society_description }).ToList();
            CustomizeDataGridView();
            dataGridView1.Refresh();
        }

        private void CustomizeDataGridView()
        {
            // Set the column widths
            dataGridView1.Columns["Society_name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns["Society_president"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns["Society_description"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            // Set the column header font size and style
            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            headerStyle.Font = new Font("Arial", 12, FontStyle.Bold);
            dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;

            // Set the row header font size and style
            dataGridView1.RowHeadersDefaultCellStyle.Font = new Font("Arial", 10);

            // Set the row height
            dataGridView1.RowTemplate.Height = 40;

            // Center align data in columns
            dataGridView1.Columns["Society_name"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Society_president"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Society_description"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Increase the font size of the data in all columns by a little
            DataGridViewCellStyle dataCellStyle = new DataGridViewCellStyle();
            dataCellStyle.Font = new Font("Arial", 11);
            dataGridView1.DefaultCellStyle = dataCellStyle;

            dataGridView1.RowsDefaultCellStyle.BackColor = Color.White;
            dataGridView1.RowsDefaultCellStyle.ForeColor = Color.Black;
            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.LightBlue;

            // Hover Effect
            dataGridView1.RowPrePaint += DataGridView1_RowPrePaint;



            // Add a search bar to filter rows based on user input
            searchTextBox.TextChanged += SearchTextBox_TextChanged;
            searchTextBox.BringToFront();
            searchTextBox.BackColor = Color.White;
            searchTextBox.ForeColor = Color.Black;
            searchTextBox.BorderStyle = BorderStyle.FixedSingle;
            searchTextBox.Text = "Search...";
            searchTextBox.GotFocus += SearchTextBox_GotFocus;
            searchTextBox.LostFocus += SearchTextBox_LostFocus;
        }

        // Handle search box got focus
        private void SearchTextBox_GotFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (textBox.Text == "Search...")
            {
                textBox.Text = string.Empty;
                textBox.ForeColor = Color.Black;
            }
        }

        // Handle search box lost focus
        private void SearchTextBox_LostFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Search...";
                textBox.ForeColor = Color.DarkGray;
            }
        }

        // Search box text changed event
        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            TextBox searchTextBox = (TextBox)sender;
            string searchKeyword = searchTextBox.Text.ToLower();
            bool cellFound = false;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchKeyword))
                    {
                        cell.Selected = true; // Select the cell if it contains the search keyword
                        dataGridView1.CurrentCell = cell; // Set this cell as the current cell
                        cellFound = true;
                        break; // Exit the inner loop after finding the first matching cell
                    }
                }

                if (cellFound)
                    break; // Exit the outer loop if the cell is found
            }
        }

        // Hover Effect
        private void DataGridView1_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (e.RowIndex % 2 == 0)
            {
                // Apply a different background color for even rows
                dataGridView1.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightCyan;
            }
            else
            {
                // Apply a different background color for odd rows
                dataGridView1.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightBlue;
            }
        }
      

       

        private void delete_Click(object sender, EventArgs e)
        {
            PersonDL.societylist.RemoveAt(dataGridView1.CurrentRow.Index);
            SocietyDL.writedatinfile();
            databind();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DisplaySocieties_Load(object sender, EventArgs e)
        {

        }
    }
}
