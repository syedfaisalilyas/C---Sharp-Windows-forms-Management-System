﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FontAwesome;
using System.Windows.Forms;
using Task_no_1.Admin;

namespace Task_no_1
{

    public partial class Adminform : Form
    {
        bool slidebarexpand;
        bool societyoptions;
        bool memberoptions;
        bool eventsoptions;
        bool missionoptions;
        private Form currentchildform;
        public Adminform(SignIn callingForm)
        {

        }

        public Adminform()
        {
            MainMenu a = new MainMenu();
            a.ShowDialog();
            InitializeComponent();
        }

        private void openform(Form childform)
        {
            if (currentchildform != null)
            {
                currentchildform.Close();
            }
            currentchildform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            mainpanel.Controls.Add(childform);
            mainpanel.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }

        private void SignInHeader_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            if(currentchildform!=null)
            currentchildform.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

       

        private void back_Click(object sender, EventArgs e)
        {

        }

        private void Date_Click(object sender, EventArgs e)
        {

        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            societytimer.Start();

        }

        private void Time_Click(object sender, EventArgs e)
        {

        }

        private void next_Click(object sender, EventArgs e)
        {

        }

        private void Admin_Load(object sender, EventArgs e)
        {
        
        }

        private void button16_Click(object sender, EventArgs e)
        {
     
        }

        private void slider_Tick(object sender, EventArgs e)
        {
            if (slidebarexpand)
            {
                slidebar.Width -= 10;
                if (slidebar.Width <= slidebar.MinimumSize.Width)
                {
                    slidebarexpand = false;
                    slider.Stop();
                }
            }
            else
            {
                slidebar.Width += 10;
                if (slidebar.Width >= slidebar.MaximumSize.Width)
                {
                    slidebarexpand = true;
                    slider.Stop();
                }

            }
        }

        private void slidebar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            slider.Start();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            openform(new DisplaySocieties());
        }
       
        private void societytimer_Tick(object sender, EventArgs e)
        {
            if (societyoptions)
            {
                societypanel.Height -= 10;
                societypanel.Width -= 10;
                if (societypanel.Height <= societypanel.MinimumSize.Height && societypanel.Width <= societypanel.MinimumSize.Width)
                {
                    societyoptions = false;
                    societytimer.Stop();
                }
            }
            else
            {
                societypanel.Height += 10;
                societypanel.Width += 10;
                if (societypanel.Height >= societypanel.MaximumSize.Height && societypanel.Width >= societypanel.MaximumSize.Width)
                {
                    societyoptions = true;
                    societytimer.Stop();
                }

            }
        }

       

        private void button22_Click_1(object sender, EventArgs e)
        {
            openform(new AddSociety());

        }

      

        private void societypanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button16_Click_1(object sender, EventArgs e)
        {
            membertimer.Start();
        }

        private void membertimer_Tick(object sender, EventArgs e)
        {
            if (memberoptions)
            {
                Memberpanel.Height -= 10;
                Memberpanel.Width -= 10;
                if (Memberpanel.Height <= Memberpanel.MinimumSize.Height && Memberpanel.Width <= Memberpanel.MinimumSize.Width)
                {
                    memberoptions = false;
                    membertimer.Stop();
                }
            }
            else
            {
                Memberpanel.Height += 10;
                Memberpanel.Width += 10;
                if (Memberpanel.Height >= Memberpanel.MaximumSize.Height && Memberpanel.Width >= Memberpanel.MaximumSize.Width)
                {
                    memberoptions = true;
                    membertimer.Stop();
                }

            }
        }

        private void button32_Click(object sender, EventArgs e)
        {
            openform(new DisplayRequests());
        }

        private void button18_Click(object sender, EventArgs e)
        {
            openform(new DisplayDonations());

        }

        private void button19_Click(object sender, EventArgs e)
        {
            openform(new DisplayFeedbacks());
        }

        private void button20_Click(object sender, EventArgs e)
        {
            missionstimer.Start();
        }

        private void missionstimer_Tick(object sender, EventArgs e)
        {
            if (missionoptions)
            {
                missionpanel.Height -= 10;
                missionpanel.Width -= 10;
                if (missionpanel.Height <= missionpanel.MinimumSize.Height && missionpanel.Width <= missionpanel.MinimumSize.Width)
                {
                    missionoptions = false;
                    missionstimer.Stop();
                }
            }
            else
            {
                missionpanel.Height += 10;
                missionpanel.Width += 10;
                if (missionpanel.Height >= missionpanel.MaximumSize.Height && missionpanel.Width >= missionpanel.MaximumSize.Width)
                {
                    missionoptions = true;
                    missionstimer.Stop();
                }

            }
        }

        private void eventstimer_Tick(object sender, EventArgs e)
        {
            if (eventsoptions)
            {
                eventpanel.Height -= 10;
                eventpanel.Width -= 10;
                if (eventpanel.Height <= eventpanel.MinimumSize.Height && eventpanel.Width <= eventpanel.MinimumSize.Width)
                {
                    eventsoptions = false;
                    eventstimer.Stop();
                }
            }
            else
            {
                eventpanel.Height += 10;
                eventpanel.Width += 10;
                if (eventpanel.Height >= eventpanel.MaximumSize.Height && eventpanel.Width >= eventpanel.MaximumSize.Width)
                {
                    eventsoptions = true;
                    eventstimer.Stop();
                }

            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            eventstimer.Start();
        }

        private void button27_Click(object sender, EventArgs e)
        {
            openform(new AddMember());
        }

        private void button25_Click(object sender, EventArgs e)
        {
            openform(new UpdateMember());
        }

        private void button26_Click(object sender, EventArgs e)
        {
            openform(new DisplayMembers());
        }

        private void button29_Click(object sender, EventArgs e)
        {
            openform(new EditEvent());
        }

        private void button28_Click(object sender, EventArgs e)
        {
            openform(new DisplayEvents());
        }

        private void button31_Click(object sender, EventArgs e)
        {

            openform(new EditMission());
        }

        private void button30_Click(object sender, EventArgs e)
        {
            openform(new DisplayMission());
        }

        private void button21_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Click(object sender, EventArgs e)
        {
            if(currentchildform !=null)
            currentchildform.Close();
        }

        private void button24_Click(object sender, EventArgs e)
        {
            openform(new UpdateSociety());
        }

        private void mainpanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            openform(new DisplaySocieties());
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            openform(new Admin.DisplayMembers());
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            openform(new Admin.DisplayEvents());

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            openform(new Admin.DisplayMission());
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            openform(new Admin.DisplayFeedbacks());
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            openform(new Admin.DisplayDonations());
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            openform(new Admin.DisplayRequests());
        }

        private void datendtime_Tick(object sender, EventArgs e)
        {
            Date.Text = "Date: " + DateTime.Now.ToString("MMMM dd, yyyy");
            Time.Text = "Time: " + DateTime.Now.ToString("hh:mm:ss tt");
        }
    }
}
