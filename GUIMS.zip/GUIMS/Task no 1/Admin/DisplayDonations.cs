﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class DisplayDonations : Form
    {
        public DisplayDonations()
        {
            InitializeComponent();
            databind();
            CustomizeDataGridView();
        }

        private void databind()
        {
            // Create a DataTable
            DataTable dataTable = new DataTable();

            // Add columns to the DataTable
            dataTable.Columns.Add("Donor Name", typeof(string));
            dataTable.Columns.Add("Donation", typeof(string));

            // Add rows to the DataTable based on the SocietyDL.Donations and SocietyDL.DonationsNames lists
            for (int i = 0; i < SocietyDL.DonationsNames.Count; i++)
            {
                DataRow row = dataTable.NewRow();
                row["Donor Name"] = SocietyDL.DonationsNames[i];
                row["Donation"] = SocietyDL.Donations[i];
                dataTable.Rows.Add(row);
            }

            // Set the DataTable as the DataGridView's DataSource
            dataGridView1.DataSource = dataTable;
        }

        private void CustomizeDataGridView()
        {
            // Increase the font size of the data in all columns
            DataGridViewCellStyle dataCellStyle = new DataGridViewCellStyle();
            dataCellStyle.Font = new Font("Arial", 11);
            dataGridView1.DefaultCellStyle = dataCellStyle;

            // Set the column widths to autosize
            dataGridView1.Columns["Donation"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns["Donor Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            // Center align data in columns
            dataGridView1.Columns["Donation"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Donor Name"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set the column header font size, style, and center alignment
            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            headerStyle.Font = new Font("Arial", 12, FontStyle.Bold);
            headerStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;

            // Set the row height
            dataGridView1.RowTemplate.Height = 40;

            // Apply alternating row colors for better readability
            dataGridView1.RowsDefaultCellStyle.BackColor = Color.White;
            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
