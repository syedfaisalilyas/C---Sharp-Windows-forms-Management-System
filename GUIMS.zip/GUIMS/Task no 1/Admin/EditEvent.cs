﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class EditEvent : Form
    {
        public EditEvent()
        {
            InitializeComponent();
        }

        private void cleardata()
        {
            eventtb.Text = "";
        }
        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void next_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(eventtb.Text))
            {
                MessageBox.Show("Event cannot be left blank.");
                eventtb.Focus();
                return;
            }
            SocietyDL.addtoeventlist(eventtb.Text);
            SocietyDL.storeevent(eventtb.Text);
            cleardata();
            this.Close();
        }

        private void EditEvent_Load(object sender, EventArgs e)
        {
           
        }
    }
}
