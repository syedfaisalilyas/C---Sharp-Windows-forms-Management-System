﻿
namespace Task_no_1.Admin
{
    partial class UpdateSociety
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.newtb = new System.Windows.Forms.TextBox();
            this.next = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.previoustb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // newtb
            // 
            this.newtb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.newtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newtb.Location = new System.Drawing.Point(379, 336);
            this.newtb.Name = "newtb";
            this.newtb.Size = new System.Drawing.Size(278, 34);
            this.newtb.TabIndex = 51;
            this.newtb.TextChanged += new System.EventHandler(this.newtb_TextChanged);
            // 
            // next
            // 
            this.next.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.next.Location = new System.Drawing.Point(618, 536);
            this.next.Name = "next";
            this.next.Size = new System.Drawing.Size(127, 40);
            this.next.TabIndex = 45;
            this.next.Text = "Next";
            this.next.UseVisualStyleBackColor = false;
            this.next.Click += new System.EventHandler(this.next_Click);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(113, 268);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(248, 27);
            this.label2.TabIndex = 42;
            this.label2.Text = "Society Previous Name :";
            // 
            // previoustb
            // 
            this.previoustb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.previoustb.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.previoustb.Location = new System.Drawing.Point(379, 262);
            this.previoustb.Name = "previoustb";
            this.previoustb.Size = new System.Drawing.Size(278, 34);
            this.previoustb.TabIndex = 41;
            this.previoustb.TextChanged += new System.EventHandler(this.previoustb_TextChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(152, 342);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 27);
            this.label1.TabIndex = 52;
            this.label1.Text = "Society New Name :";
            // 
            // UpdateSociety
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(855, 640);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.newtb);
            this.Controls.Add(this.next);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.previoustb);
            this.Name = "UpdateSociety";
            this.Text = "UpdateSociety";
            this.Load += new System.EventHandler(this.UpdateSociety_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox newtb;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox previoustb;
        private System.Windows.Forms.Label label1;
    }
}