﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class DisplayFeedbacks : Form
    {
        private DataTable table;

        public DisplayFeedbacks()
        {
            InitializeComponent();
            databind();
        }

        private void databind()
        {
            dataGridView1.DataSource = null;
            table = new DataTable();
            table.Columns.Add("Feedbacks");

            foreach (string feedback in SocietyDL.Feedback)
            {
                DataRow row = table.NewRow();
                row["Feedbacks"] = feedback;
                table.Rows.Add(row);
            }

            dataGridView1.DataSource = table;
            dataGridView1.RowTemplate.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView1.DefaultCellStyle.Font = new Font("Times New Roman", 12);
            dataGridView1.Columns["Feedbacks"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.RowTemplate.Height = 30;

            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            headerStyle.Font = new Font("Arial", 12, FontStyle.Bold);
            headerStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;

            dataGridView1.Refresh();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
         }

        private void delete_Click(object sender, EventArgs e)
        {
            SocietyDL.Feedback.RemoveAt(dataGridView1.CurrentRow.Index);
            SocietyDL.writedatinfeedbackfile();
            databind();
        }
    }
    }
