﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.BL;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class UpdateSociety : Form
    {
        public UpdateSociety()
        {
            InitializeComponent();
        }

        private void cleardatafromform()
        {
            previoustb.Text = "";
            newtb.Text = "";
        }
     

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }


      
        private void previoustb_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string prev = previoustb.Text;
            if (!u.isString(prev))
            {
                MessageBox.Show("Invalid Name! Please enter a Valid Name.");
                previoustb.Clear();
                previoustb.Focus();
            }
    }
  
        private void newtb_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string prev = previoustb.Text;
            if (!u.isString(prev))
            {
                MessageBox.Show("Invalid Name! Please enter a Valid Name.");
                previoustb.Clear();
                previoustb.Focus();
            }
    }

        private void UpdateSociety_Load(object sender, EventArgs e)
        {
           
        }

        private void next_Click(object sender, EventArgs e)
        {
            bool flag = false;
            string previousname = previoustb.Text;
            string newname = newtb.Text;
            foreach (Society i in PersonDL.societylist)
            {
                if (i.Society_name == previousname)
                {
                    i.Society_name = newname;
                    SocietyDL.writedatinfile();
                    MessageBox.Show("Society name changed successfully!");
                    this.Close();
                    flag = true;
                    break;
                }
            }
            if (flag == true)
            {
                MessageBox.Show("Society name not found!");
                cleardatafromform();
            }
        }
    }
}
