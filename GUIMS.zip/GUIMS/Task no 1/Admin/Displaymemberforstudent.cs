﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class Displaymemberforstudent : Form
    {
        public Displaymemberforstudent()
        {
            InitializeComponent();
            databind();
        }
        private void databind()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = PersonDL.societyuserlist.Select(c => new { c.Society_member_username, c.Society_member_email, c.Society_member_contact }).ToList();
            CustomizeDataGridView();
            dataGridView1.Refresh();
        }
        private void CustomizeDataGridView()
        {
            // Set the AutoSizeMode for each column to fit the content
            dataGridView1.Columns["Society_member_username"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns["Society_member_email"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns["Society_member_contact"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            // Set the column headers' font size, style, and alignment
            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            headerStyle.Font = new Font("Arial", 12, FontStyle.Bold);
            headerStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;


            // Set the row height
            dataGridView1.RowTemplate.Height = 40;

            // Increase the font size of the data in all columns by a little
            DataGridViewCellStyle dataCellStyle = new DataGridViewCellStyle();
            dataCellStyle.Font = new Font("Arial", 11);
            dataGridView1.DefaultCellStyle = dataCellStyle;

            // Center align data in columns
            dataGridView1.Columns["Society_member_username"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Society_member_email"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Society_member_contact"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Apply alternating row colors for better readability
            dataGridView1.RowsDefaultCellStyle.BackColor = Color.White;
            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
