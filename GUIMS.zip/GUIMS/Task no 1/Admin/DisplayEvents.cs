﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class DisplayEvents : Form
    {
        private DataTable table;
        public DisplayEvents()
        {
            InitializeComponent();
            databind();
        }
        private void databind()
        {
            dataGridView1.DataSource = null;
            table = new DataTable();
            table.Columns.Add("Events");

            foreach (string ev in SocietyDL.Eventlist)
            {
                DataRow row = table.NewRow();
                row["Events"] = ev;
                table.Rows.Add(row);
            }

            dataGridView1.DataSource = table;
            dataGridView1.RowTemplate.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView1.DefaultCellStyle.Font = new Font("Times New Roman", 12);
            dataGridView1.Columns["Events"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.RowTemplate.Height = 35;

            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            dataGridView1.Columns["Events"].HeaderCell.Style.Padding = new Padding(0, 20, 0, 0); 
            headerStyle.Font = new Font(dataGridView1.Font, FontStyle.Bold);
            headerStyle.Font =  new Font("Times New Roman", 14,FontStyle.Bold);
            dataGridView1.Columns["Events"].HeaderCell.Style = headerStyle;
            dataGridView1.Refresh();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void delete_Click(object sender, EventArgs e)
        {
            SocietyDL.Eventlist.RemoveAt(dataGridView1.CurrentRow.Index);
            SocietyDL.writedatinEVENTfile();
            databind();
        }

        private void DisplayEvents_Load(object sender, EventArgs e)
        {

        }
    }
}
