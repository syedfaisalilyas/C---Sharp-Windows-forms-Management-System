﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Task_no_1.BL;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class RemoveMember : Form
    {
        public RemoveMember()
        {
            InitializeComponent();
            InitializeCustomButton();
        }

        private void InitializeCustomButton()
        {
            RoundedButton customButton = new RoundedButton();
            customButton.Text = "Remove Member";
            customButton.Location = new Point(100, 100);
            customButton.Size = new Size(150, 50); // Set the size of the button
            customButton.Color1 = Color.FromArgb(255, 128, 0); // Set the first gradient color
            customButton.Color2 = Color.FromArgb(255, 200, 64); // Set the second gradient color
            customButton.ForeColor = Color.White; // Set the text color
            customButton.Font = new Font("Arial", 12, FontStyle.Bold); // Set the font and style of the text
            customButton.CornerRadius = 15; // Set the corner radius for rounded edges
            customButton.Click += next_Click; // Hook up the click event to your existing next_Click method
            this.Controls.Add(customButton);
        }

        private void cleardata()
        {
            usernametb.Text = "";
        }

        private void usernametb_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string name = usernametb.Text;
            if (!u.isString(name))
            {
                MessageBox.Show("Invalid Role! Please enter a valid Name.");
                usernametb.Clear();
                usernametb.Focus();
            }
        }

        private void RemoveMember_Load(object sender, EventArgs e)
        {

        }

        private void next_Click(object sender, EventArgs e)
        {
            bool flag = false;
            string name = usernametb.Text;
            foreach (SocietyMember i in SocietyMemberDL.societyuserlist)
            {
                if (i.Society_member_username == name)
                {
                    SocietyMemberDL.societyuserlist.Remove(i);
                    SocietyMemberDL.writedatinfile();
                    MessageBox.Show("Society Member removed successfully!");
                    this.Close();
                }
                flag = true;
            }
            if (flag == true)
            {
                MessageBox.Show("Member not found!");
                cleardata();
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    // Custom RoundedButton class
    public class RoundedButton : Button
    {
        public Color Color1 { get; set; }
        public Color Color2 { get; set; }
        public int CornerRadius { get; set; }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            Rectangle bounds = new Rectangle(0, 0, this.Width, this.Height);

            // Create the rounded rectangle path
            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddArc(bounds.X, bounds.Y, CornerRadius * 2, CornerRadius * 2, 180, 90);
                path.AddArc(bounds.X + bounds.Width - CornerRadius * 2, bounds.Y, CornerRadius * 2, CornerRadius * 2, 270, 90);
                path.AddArc(bounds.X + bounds.Width - CornerRadius * 2, bounds.Y + bounds.Height - CornerRadius * 2, CornerRadius * 2, CornerRadius * 2, 0, 90);
                path.AddArc(bounds.X, bounds.Y + bounds.Height - CornerRadius * 2, CornerRadius * 2, CornerRadius * 2, 90, 90);
                path.CloseFigure();

                // Fill the button with a gradient color
                using (LinearGradientBrush brush = new LinearGradientBrush(bounds, Color1, Color2, LinearGradientMode.Vertical))
                {
                    g.FillPath(brush, path);
                }

                // Draw a shadow effect
                Rectangle shadowBounds = new Rectangle(bounds.X + 5, bounds.Y + 5, bounds.Width - 5, bounds.Height - 5);
                using (GraphicsPath shadowPath = new GraphicsPath())
                {
                    shadowPath.AddArc(shadowBounds.X, shadowBounds.Y, CornerRadius * 2, CornerRadius * 2, 180, 90);
                    shadowPath.AddArc(shadowBounds.X + shadowBounds.Width - CornerRadius * 2, shadowBounds.Y, CornerRadius * 2, CornerRadius * 2, 270, 90);
                    shadowPath.AddArc(shadowBounds.X + shadowBounds.Width - CornerRadius * 2, shadowBounds.Y + shadowBounds.Height - CornerRadius * 2, CornerRadius * 2, CornerRadius * 2, 0, 90);
                    shadowPath.AddArc(shadowBounds.X, shadowBounds.Y + shadowBounds.Height - CornerRadius * 2, CornerRadius * 2, CornerRadius * 2, 90, 90);
                    shadowPath.CloseFigure();

                    Color shadowColor = Color.FromArgb(100, Color.Black);
                    using (SolidBrush shadowBrush = new SolidBrush(shadowColor))
                    {
                        g.FillPath(shadowBrush, shadowPath);
                    }
                }
            }

            // Draw the button text
            SizeF stringSize = g.MeasureString(this.Text, this.Font);
            PointF stringLocation = new PointF((this.Width - stringSize.Width) / 2, (this.Height - stringSize.Height) / 2);
            g.DrawString(this.Text, this.Font, new SolidBrush(this.ForeColor), stringLocation);
        }
    }
}
