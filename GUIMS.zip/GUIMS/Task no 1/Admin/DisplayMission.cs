﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.BL;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class DisplayMission : Form
    {
        private DataTable table;
        public DisplayMission()
        {
            InitializeComponent();
            databind();
        
        }
        private void DisplayMission_Load(object sender, EventArgs e)
        {
            
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void databind()
        {
            dataGridView1.DataSource = null;
            table = new DataTable();
            table.Columns.Add("Missions");

            foreach (string mission in SocietyDL.Missions)
            {
                DataRow row = table.NewRow();
                row["Missions"] = mission;
                table.Rows.Add(row);
            }

            dataGridView1.DataSource = table;
            dataGridView1.RowTemplate.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView1.DefaultCellStyle.Font = new Font("Times New Roman", 12);
            dataGridView1.Columns["Missions"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.RowTemplate.Height = 30;

            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            headerStyle.Font = new Font("Arial", 12, FontStyle.Bold);
            headerStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;

            dataGridView1.Refresh();
        }
        private void mission1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void delete_Click(object sender, EventArgs e)
        {
            SocietyDL.Missions.RemoveAt(dataGridView1.CurrentRow.Index);
            SocietyDL.writedatinMissionfile();
            databind();
        }
    }
}
