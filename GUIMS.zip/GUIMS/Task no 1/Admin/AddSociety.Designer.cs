﻿
namespace Task_no_1.Admin
{
    partial class AddSociety
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.presidenttext = new System.Windows.Forms.TextBox();
            this.descriptiontext = new System.Windows.Forms.TextBox();
            this.next = new System.Windows.Forms.Button();
            this.nametext = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // presidenttext
            // 
            this.presidenttext.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.presidenttext.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.presidenttext.Location = new System.Drawing.Point(357, 291);
            this.presidenttext.Name = "presidenttext";
            this.presidenttext.Size = new System.Drawing.Size(278, 38);
            this.presidenttext.TabIndex = 55;
            this.presidenttext.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // descriptiontext
            // 
            this.descriptiontext.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.descriptiontext.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptiontext.Location = new System.Drawing.Point(357, 360);
            this.descriptiontext.Name = "descriptiontext";
            this.descriptiontext.Size = new System.Drawing.Size(278, 38);
            this.descriptiontext.TabIndex = 54;
            // 
            // next
            // 
            this.next.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.next.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.next.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.next.Location = new System.Drawing.Point(583, 486);
            this.next.Name = "next";
            this.next.Size = new System.Drawing.Size(162, 58);
            this.next.TabIndex = 53;
            this.next.Text = "Add";
            this.next.UseVisualStyleBackColor = false;
            this.next.Click += new System.EventHandler(this.next_Click);
            // 
            // nametext
            // 
            this.nametext.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nametext.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nametext.Location = new System.Drawing.Point(357, 226);
            this.nametext.Name = "nametext";
            this.nametext.Size = new System.Drawing.Size(278, 38);
            this.nametext.TabIndex = 52;
            this.nametext.TextChanged += new System.EventHandler(this.usernametb_TextChanged);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(146, 231);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(177, 33);
            this.label5.TabIndex = 57;
            this.label5.Text = "Society Name:";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(106, 296);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(217, 33);
            this.label7.TabIndex = 59;
            this.label7.Text = "Society President:";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(80, 365);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(243, 33);
            this.label8.TabIndex = 60;
            this.label8.Text = "Society Description:";
            // 
            // AddSociety
            // 
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(855, 640);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.presidenttext);
            this.Controls.Add(this.descriptiontext);
            this.Controls.Add(this.next);
            this.Controls.Add(this.nametext);
            this.Name = "AddSociety";
            this.Load += new System.EventHandler(this.AddSociety_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    
        private System.Windows.Forms.TextBox presidenttext;
        private System.Windows.Forms.TextBox descriptiontext;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.TextBox nametext;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}