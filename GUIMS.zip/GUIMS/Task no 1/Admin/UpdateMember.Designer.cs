﻿
namespace Task_no_1.Admin
{
    partial class UpdateMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.newtb = new System.Windows.Forms.TextBox();
            this.next = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.previoustb = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(129, 339);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 27);
            this.label1.TabIndex = 61;
            this.label1.Text = "Member New Name :";
            // 
            // newtb
            // 
            this.newtb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.newtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newtb.Location = new System.Drawing.Point(384, 333);
            this.newtb.Name = "newtb";
            this.newtb.Size = new System.Drawing.Size(278, 34);
            this.newtb.TabIndex = 60;
            this.newtb.TextChanged += new System.EventHandler(this.newtb_TextChanged);
            // 
            // next
            // 
            this.next.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.next.Location = new System.Drawing.Point(609, 517);
            this.next.Name = "next";
            this.next.Size = new System.Drawing.Size(118, 43);
            this.next.TabIndex = 55;
            this.next.Text = "Next";
            this.next.UseVisualStyleBackColor = false;
            this.next.Click += new System.EventHandler(this.next_Click);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(90, 265);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(258, 27);
            this.label2.TabIndex = 54;
            this.label2.Text = "Member Previous Name :";
            // 
            // previoustb
            // 
            this.previoustb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.previoustb.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.previoustb.Location = new System.Drawing.Point(384, 259);
            this.previoustb.Name = "previoustb";
            this.previoustb.Size = new System.Drawing.Size(278, 34);
            this.previoustb.TabIndex = 53;
            this.previoustb.TextChanged += new System.EventHandler(this.previoustb_TextChanged);
            // 
            // UpdateMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(855, 640);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.newtb);
            this.Controls.Add(this.next);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.previoustb);
            this.Name = "UpdateMember";
            this.Text = "UpdateMember";
            this.Load += new System.EventHandler(this.UpdateMember_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox newtb;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox previoustb;
    }
}