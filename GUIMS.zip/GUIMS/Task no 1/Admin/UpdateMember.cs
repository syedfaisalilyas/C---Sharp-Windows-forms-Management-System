﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_no_1.BL;
using Task_no_1.DL;

namespace Task_no_1.Admin
{
    public partial class UpdateMember : Form
    {
        public UpdateMember()
        {
            InitializeComponent();
        }

        private void cleardatafromform()
        {
            previoustb.Text = "";
            newtb.Text = "";
        }
        private void previoustb_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string prev = previoustb.Text;
            if (!u.isString(prev))
            {
                MessageBox.Show("Invalid Name! Please enter a Valid Name.");
                previoustb.Clear();
                previoustb.Focus();
            }
        }

        private void newtb_TextChanged(object sender, EventArgs e)
        {
            MUser u = new MUser();
            string new1 = newtb.Text;
            if (!u.isString(new1))
            {
                MessageBox.Show("Invalid Name! Please enter a Valid Name.");
                newtb.Clear();
                newtb.Focus();
            }
        }

        private void UpdateMember_Load(object sender, EventArgs e)
        {
          
        }

        private void next_Click(object sender, EventArgs e)
        {
            bool flag = false;
            string previousname = previoustb.Text;
            string newname = newtb.Text;
            foreach(SocietyMember i in SocietyMemberDL.societyuserlist)
            {
                if(i.Society_member_username == previousname)
                {
                    i.Society_member_username = newname;
                    SocietyMemberDL.writedatinfile();
                    MessageBox.Show("Society Member Name changed successfully!");
                    this.Close();
                }
                flag = true;
            }
            if(flag == true)
            {
                MessageBox.Show("Name not found!");
                cleardatafromform();
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
