﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task_no_1.BL;

namespace Task_no_1.DL
{
    class MUserDL:PersonDL
    {
        public static List<MUser> Loginusers { get => loginusers; set => loginusers = value; }

        public static void AddtoUserlist(MUser user)
        {
            loginusers.Add(user);
        }

        public static MUser SignIn(MUser User)
        {
            foreach(MUser storeduser in loginusers)
            {
                if(storeduser.Name1 == User.Name1  && storeduser.Password1 == User.Password1)
                {
                    return storeduser;
                }
            }
            return null;
        }

        public static void storedata(MUser user,string path)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(user.Name1 + "," + user.Password1 + "," + user.Phone1 + "," + user.Email1 + "," +user.Role1);
            file.Flush();
            file.Close();

        }

        public static bool readdata(string path)
        {
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    MUser user = new MUser();
                    string[] splittedrecord = record.Split(',');
                    user.Name1 = splittedrecord[0];
                    user.Password1 = splittedrecord[1] ;
                    user.Phone1 = splittedrecord[2];
                    user.Email1 = splittedrecord[3];
                    user.Role1 = splittedrecord[4];
                    AddtoUserlist(user);
                }
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
