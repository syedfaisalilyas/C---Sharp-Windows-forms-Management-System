﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task_no_1.BL;

namespace Task_no_1.DL
{
    class SocietyDL
    {
        private static List<string> feedback = new List<string>();
        private static List<string> eventlist = new List<string>();
        private static List<string> requestlist = new List<string>();
        private static List<string> donations = new List<string>();
        private static List<string> donationsNames = new List<string>();
        private static List<string> missions = new List<string>();
        public static List<string> Feedback { get => feedback; set => feedback = value; }
        public static List<string> Eventlist { get => eventlist; set => eventlist = value; }
        public static List<string> Requestlist { get => requestlist; set => requestlist = value; }
        public static List<string> Donations { get => donations; set => donations = value; }
        public static List<string> DonationsNames { get => donationsNames; set => donationsNames = value; }
        public static List<string> Missions { get => missions; set => missions = value; }

        public static void addtofeedbacklist(string a)
        {
            feedback.Add(a);
        }
        public static void addtoeventlist(string a)
        {
            eventlist.Add(a);
        } 
        public static void addtomissionlist(string a)
        {
            missions.Add(a);
        }
        public static void addtorequestlist(string a)
        {
            requestlist.Add(a);
        }

        public static void addtodonationslist(string a)
        {
            donations.Add(a);
        }
        public static void addtodonationNameslist(string a)
        {
            donationsNames.Add(a);
        }

        public static void addtosociety(Society s1)
        {
            PersonDL.societylist.Add(s1);
        }

        public void storesocietydata(Society s1)
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\societydata.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(s1.Society_name + "," + s1.Society_president + "," + s1.Society_description);
            file.Flush();
            file.Close();

        }

        public static void readsocietydata()
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\societydata.txt";
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    string[] splittedrecord = record.Split(',');
                    Society b = new Society();
                    b.Society_name = (splittedrecord[0]);
                    b.Society_president = (splittedrecord[1]);
                    b.Society_description =(splittedrecord[2]);
                    addtosociety(b);
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("Not Exists");
            }
        }

        public static void writedatinfile()
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\societydata.txt";
            StreamWriter file = new StreamWriter(path);
            foreach (Society i in PersonDL.societylist)
            {
                file.WriteLine(i.Society_name + "," + i.Society_president + "," + i.Society_description);
            }
            file.Flush();
            file.Close();


        }

        public void storefeedback(string f)
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Feedback.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(f);
            file.Flush();
            file.Close();
        }

        public static void loadfeedback()
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Feedback.txt";
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    addtofeedbacklist(record);
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("Not Exists");
            }
        }
        public static void writedatinfeedbackfile()
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Feedback.txt";
            StreamWriter file = new StreamWriter(path);
            foreach(string feedback in Feedback)
            {
            file.WriteLine(feedback);
            }
            file.Flush();
            file.Close();


        }
        public static void storeevent(string e)
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Events.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(e);
            file.Flush();
            file.Close();
        }

        public static void loadevent()
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Events.txt";
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    addtoeventlist(record);
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("Not Exists");
            }
        }
        public static void writedatinEVENTfile()
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Events.txt";
            StreamWriter file = new StreamWriter(path);
            foreach (string ev in eventlist)
            {
                file.WriteLine(ev);
            }
            file.Flush();
            file.Close();


        }   public static void storemission(string m)
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Missions.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(m);
            file.Flush();
            file.Close();
        }

        public static void loadmission()
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Missions.txt";
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    addtomissionlist(record);
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("Not Exists");
            }
        }
        public static void writedatinMissionfile()
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Missions.txt";
            StreamWriter file = new StreamWriter(path);
            foreach (string m in missions)
            {
                file.WriteLine(m);
            }
            file.Flush();
            file.Close();


        }
        public void storereq(string req)
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Request.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(req);
            file.Flush();
            file.Close();
        }

        public static void loadreq()
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Request.txt";
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    addtorequestlist(record);
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("Not Exists");
            }
        }

        public void storedonation(string don, string name)
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Donations.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(don + "," + name);
            file.Flush();
            file.Close();
        }

        public static void loaddonation()
        {
            PersonDL a = new PersonDL();
            string path = "C:\\OOP\\GUIMS\\GUIMS\\Donations.txt";
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    string[] splittedrecord = record.Split(',');
                    addtodonationNameslist(splittedrecord[0]);
                    addtodonationslist(splittedrecord[1]);
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("Not Exists");
            }
        }
    }
}
