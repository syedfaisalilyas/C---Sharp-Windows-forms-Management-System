﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task_no_1.BL;

namespace Task_no_1.DL
{
    class SocietyMemberDL : PersonDL
    {
        public static void addtosocietyUsers(SocietyMember s1)
        {
            societyuserlist.Add(s1);
        }

        public void storememberdata(SocietyMember s)
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\memberdata.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(s.Society_member_username + "," + s.Society_member_email + "," + s.Society_member_contact);
            file.Flush();
            file.Close();
        }

        public static void readmemberdata()
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\memberdata.txt";
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    string[] splittedrecord = record.Split(',');
                    SocietyMember so = new SocietyMember();
                    so.Society_member_username = (splittedrecord[0]);
                    so.Society_member_email = (splittedrecord[1]);
                    so.Society_member_contact = (splittedrecord[2]);
                    societyuserlist.Add(so);
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("Not exists");
            }
        }

        public static  void writedatinfile()
        {
            string path = "C:\\OOP\\GUIMS\\GUIMS\\memberdata.txt";
            StreamWriter file = new StreamWriter(path);
            foreach (SocietyMember i in societyuserlist)
            {
                file.WriteLine(i.Society_member_username + "," + i.Society_member_email + "," + i.Society_member_contact);
            }
            file.Flush();
            file.Close();

        }

    }
}
