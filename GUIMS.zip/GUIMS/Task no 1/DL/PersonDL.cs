﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task_no_1.BL;

namespace Task_no_1.DL
{
    class PersonDL
    {
        public static List<MUser> loginusers = new List<MUser>();
        public static List<SocietyMember> societyuserlist = new List<SocietyMember>();
        public static List<Society> societylist = new List<Society>();
    }
}
